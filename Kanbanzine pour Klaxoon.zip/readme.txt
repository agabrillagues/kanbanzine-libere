Cette archive contient tous les éléments nécessaires pour mettre en place et animer une session de Kanbanzine, "jeu sérieux" de découverte de Kanban.

Il est cependant préférable d'avoir a minima déjà participé à une session du jeu et d'avoir une expérience (même modeste) de la facilitation d'ateliers en ligne.

Eléments fournis :
 + répertoire "1 - docs" :
  - Guide du facilitateur Kanbanzine en ligne : à lire ne priorité, inclue notamment la version détaillée du déroulement d'une partie de Kanbanzine
  - Regles Kanbanzine en ligne
  - Memo facilitateur Kanbanzine en ligne : à garder sous la main lorsque vous facilitez une session de Kanbanzine
  - Memo regles Kanbanzine en ligne : à partager avec les participants si vous le jugez bon
Les documents sont fournis au format Open Office (modifiable) et PDF (pour l'aspect pratique).
 + répertoire "2 - template Klaxoon" : template à importer sur Klaxoon
 + répertoire "3 - cartes animateur" : images des cartes que le facilitateur ajoute sur le plateau Kanbanzine à certains moments clefs du scénario de base
 + répertoire "4 - graphiques" : fiche de score et graphiques de suivi classiques (suivi des délais et diagramme de flux cumulés).


Cette adaptation est basée sur la version open source du jeu.
Le kit imprimable disponible en téléchargement ici : https://drive.google.com/file/d/0B3pYRpdnmDd0a2RjNnhSWXQ5YkE/view?usp=sharing

Si vous souhaitez vous procurer une version commerciale du jeu, fabriquée avec dse matériaux durables et de qualité : https://www.developperlestalents.fr/#jeux
La version actuellement commercialisée est une V2, qui comporte des améliorations par rapport à la version que vous avez entre les mains (équilibrage du jeu, diminution de l'effort de facilitation, etc.).
A noter : une version digitale de Kanbanzine v2 existe aussi, et elle a été mise à la disposition des possesseurs de la v2 physique.
Je n'ai aucun lien avec cette société mais j'ai fait partie de l'équipe qui a créé la version open source ainsi que la v2.

En cas de besoin, si vous avez des questions ou envie de partager des retours, n'hésitez pas à m'écrire à l'adresse mail suivante : agabrillagues@gmail.com

Bon jeu à vous !

Anne Gabrillagues